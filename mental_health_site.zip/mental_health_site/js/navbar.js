// Handle navbar dropdown behavior
document.addEventListener('DOMContentLoaded', function() {
    const mainNav = document.querySelector('.main-nav');
    const dropdowns = document.querySelectorAll('.main-nav .dropdown');
    const isMobile = () => window.innerWidth < 992;
    let currentDropdown = null;

    function closeCurrentDropdown() {
        if (currentDropdown) {
            const instance = bootstrap.Dropdown.getInstance(currentDropdown.querySelector('.dropdown-toggle'));
            if (instance) {
                instance.hide();
                currentDropdown = null;
            }
        }
    }

    // Initialize dropdowns
    dropdowns.forEach(dropdown => {
        const toggle = dropdown.querySelector('.dropdown-toggle');
        const menu = dropdown.querySelector('.dropdown-menu');
        
        // Initialize Bootstrap dropdown
        const dropdownInstance = new bootstrap.Dropdown(toggle, {
            autoClose: false // We'll handle closing manually
        });

        // Desktop behavior
        if (!isMobile()) {
            // Show on hover
            dropdown.addEventListener('mouseenter', () => {
                if (currentDropdown && currentDropdown !== dropdown) {
                    closeCurrentDropdown();
                }
                dropdownInstance.show();
                currentDropdown = dropdown;
            });

            // Hide on mouse leave
            dropdown.addEventListener('mouseleave', () => {
                if (currentDropdown === dropdown) {
                    closeCurrentDropdown();
                }
            });
        }

        // Mobile behavior
        toggle.addEventListener('click', (e) => {
            if (isMobile()) {
                e.preventDefault();
                e.stopPropagation();

                if (dropdown.classList.contains('show')) {
                    closeCurrentDropdown();
                } else {
                    if (currentDropdown && currentDropdown !== dropdown) {
                        closeCurrentDropdown();
                    }
                    dropdownInstance.show();
                    currentDropdown = dropdown;
                }
            }
        });

        // Show/Hide animations
        toggle.addEventListener('show.bs.dropdown', () => {
            dropdown.classList.add('show');
            menu.style.display = 'block';
            requestAnimationFrame(() => {
                menu.classList.add('showing');
            });
        });

        toggle.addEventListener('hide.bs.dropdown', () => {
            menu.classList.remove('showing');
            dropdown.classList.remove('show');
            setTimeout(() => {
                menu.style.display = '';
            }, 300);
        });

        // Handle dropdown items
        menu.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', () => {
                if (isMobile()) {
                    closeCurrentDropdown();
                }
            });
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!mainNav.contains(e.target)) {
            closeCurrentDropdown();
        }
    });

    // Handle window resize
    window.addEventListener('resize', () => {
        closeCurrentDropdown();
    });
});