// Apply theme automatically based on system preference (no manual toggle)
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');

function apply(pref) {
    if (pref.matches) document.body.setAttribute('data-theme', 'dark');
    else document.body.removeAttribute('data-theme');
}

// Check localStorage first, then apply system preference
const saved = localStorage.getItem('theme');
if (saved) {
    if (saved === 'dark') document.body.setAttribute('data-theme', 'dark');
    else document.body.removeAttribute('data-theme');
}
// If user has not saved a preference, apply system preference now
if (!saved) apply(prefersDark);

// Listen for system theme changes (modern API)
if (typeof prefersDark.addEventListener === 'function') {
    prefersDark.addEventListener('change', apply);
} else if (typeof prefersDark.addListener === 'function') {
    // fallback for older browsers
    prefersDark.addListener(apply);
}